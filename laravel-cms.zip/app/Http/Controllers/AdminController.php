<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use App\Models\heroSection;

class AdminController extends Controller
{

    public function __invoke()
    {
        return view('admin.layouts.app');
    }

    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);
    }

    public function store(Request $request)
    {
        heroSection::create(['input_value' => $request->inputValue]);

        return response()->json(['message' => 'Data stored successfully']);
    }

    public function fetchData()
    {
        $data = heroSection::latest()->first();

        return response()->json(['data' => $data]);
    }

    public function displayData()
    {
        $dataFromDatabase = heroSection::latest()->value('input_value'); // Adjust the query based on your needs

        return view('welcome.blade.view', compact('dataFromDatabase'));
    }

    //     $credentials = $request->only('email', 'password');

    //     if (Auth::attempt($credentials)) {
    //         $user = Auth::user();
    //         $token = $user->createToken('token-name')->plainTextToken;

    //         return response()->json(['token' => $token, 'user' => $user], 200);
    //     }

    //     throw ValidationException::withMessages([
    //         'email' => ['The provided credentials are incorrect.'],
    //     ]);
    // }

    // public function logout(Request $request)
    // {
    //     $request->user()->currentAccessToken()->delete();

    //     return response()->json(['message' => 'Logged out successfully']);
    // }


}
